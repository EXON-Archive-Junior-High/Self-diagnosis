# Self-diagnosis
매일 아침 상쾌하게 일어납시다.

## 사용법
1. chrome://version 에 들어가 자신의 버전을 확인하고 그 버전에 맞는 크롬드라이버를 설치한다. ([설치하기](https://sites.google.com/a/chromium.org/chromedriver/downloads))
2. [자가진단 프로그램 설치](https://github.com/1-EXON/Self-diagnosis/releases/download/v1.0/file.zip)
2. 자가진단 프로그램을 압축을 풀고 setting.txt에 크롬 드라이버 위치,자신의 이름,자신의 학교 이름,자신의 생일을 입력.
ex)D:/chromedriver.exe,홍길동,안녕중학교,071022
3. main.exe 실행
